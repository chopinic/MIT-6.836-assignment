#include "renderer.h"

renderer::renderer(const std::string& bp) : basepath(bp) {

}